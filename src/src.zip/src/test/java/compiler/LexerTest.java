package compiler;

import java.util.ArrayList;
import java.util.ListIterator;

import compiler.lexer.Lexer;
import compiler.token.Token;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class LexerTest extends TestCase {

    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public LexerTest(  )
    {
        super(  );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( LexerTest.class );
    }
    private String calc(String input) {
    	StringBuffer sb = new StringBuffer();
		
    	Lexer lexer = new Lexer(null, input);
		ArrayList<Token> list = lexer.makeToken();
		
		for(ListIterator<Token> itr = list.listIterator(); itr.hasNext(); )
			sb.append(String.format("%s ", itr.next().toString()));
		
		return sb.toString();    	
    }
    
    public void testLexerAdd(){
    	final String input = "5+1";
    	final String output = "[TT_INT:5] [TT_PLUS:+] [TT_INT:1] [TT_EOF:Position [idx=3, ln=0, col=3]] ";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
    public void testLexerSub(){
    	final String input = "5-1";
    	final String output = "[TT_INT:5] [TT_MINUS:-] [TT_INT:1] [TT_EOF:Position [idx=3, ln=0, col=3]] ";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
    public void testLexerMul(){
    	final String input = "5*1";
    	final String output = "[TT_INT:5] [TT_MUL:*] [TT_INT:1] [TT_EOF:Position [idx=3, ln=0, col=3]] ";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
    public void testLexerDiv(){
    	final String input = "5/1";
    	final String output = "[TT_INT:5] [TT_DIV:/] [TT_INT:1] [TT_EOF:Position [idx=3, ln=0, col=3]] ";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
    public void testLexerFloat() {
    	final String input = "5.0+1.1";
    	final String output = "[TT_FLOAT:5.0] [TT_PLUS:+] [TT_FLOAT:1.1] [TT_EOF:Position [idx=7, ln=0, col=7]] ";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
    public void testLexerOrder(){
    	final String input = "(5+1)+2";
    	final String output = "[TT_LPAREN:(] [TT_INT:5] [TT_PLUS:+] [TT_INT:1] [TT_RPAREN:)] [TT_PLUS:+] [TT_INT:2] [TT_EOF:Position [idx=7, ln=0, col=7]] ";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
    public void testLexerNonOrder(){
    	final String input = "5+1+2";
    	final String output = "[TT_INT:5] [TT_PLUS:+] [TT_INT:1] [TT_PLUS:+] [TT_INT:2] [TT_EOF:Position [idx=5, ln=0, col=5]] ";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
    public void testLexerNegative(){
    	final String input = "-5+1";
    	final String output = "[TT_MINUS:-] [TT_INT:5] [TT_PLUS:+] [TT_INT:1] [TT_EOF:Position [idx=4, ln=0, col=4]] ";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
}
