package compiler;

import java.util.ArrayList;
import java.util.ListIterator;

import compiler.interpreter.Context;
import compiler.interpreter.Interpreter;
import compiler.lexer.Lexer;
import compiler.parser.Parser;
import compiler.result.ParseResult;
import compiler.token.Token;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class RuntimeResultsTest extends TestCase {

    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public RuntimeResultsTest(  )
    {
        super(  );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( RuntimeResultsTest.class );
    }
    private String calc(String input) {
        Interpreter i = new Interpreter();
        Context context = new Context("<program>");
		
    	Lexer lexer = new Lexer(null, input);
		ArrayList<Token> list = lexer.makeToken();
		Parser parser = new Parser(list);
		ParseResult abs = (compiler.result.ParseResult) parser.parse();
		compiler.result.Number result = i.visit(abs.getNode(), context);
		
		return result.toString();    	
    }
    
    public void testRuntimeResultsAdd(){
    	final String input = "5+1";
    	final String output = "6";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
    public void testRuntimeResultsSub(){
    	final String input = "5-1";
    	final String output = "4";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
    public void testRuntimeResultsMul(){
    	final String input = "5*1";
    	final String output = "5";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
    public void testRuntimeResultsDiv(){
    	final String input = "5/1";
    	final String output = "5";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
    public void testRuntimeResultsFloat() {
    	final String input = "5.0+1.1";
    	final String output = "6.1";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
    public void testRuntimeResultsOrder(){
    	final String input = "(5+1)+2";
    	final String output = "8";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
    public void testRuntimeResultsNonOrder(){
    	final String input = "5+1+2";
    	final String output = "8";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
    public void testRuntimeResultsSigned(){
    	final String input = "-5";
    	final String output = "-5";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
    public void testRuntimeResultsSignedMath(){
    	final String input = "-5+1";
    	final String output = "-4";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
    public void testRuntimeResultsSignedInv(){
    	final String input = "--5";
    	final String output = "5";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
    public void testRuntimeResultsSignedDouble(){
    	final String input = "5.2+-1.3";
    	final String output = "3.8999999";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
    public void testRuntimeResultsPowered(){
    	final String input = "2^2";
    	final String output = "4.0";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
    public void testRuntimeResultsFactorialInteger(){
    	final String input = "3!";
    	final String output = "6";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
    public void testRuntimeResultsFactorialFloat(){
    	final String input = "3.2!";
    	final String output = "24.0";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
    public void testRuntimeResultsPerfect(){
    	final String input = "16%4";
    	final String output = "0";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
    public void testRuntimeResultsModImperfect(){
    	final String input = "16%3";
    	final String output = "1";
    	String result = this.calc(input);
    	assertEquals(result, output);
    }
}
