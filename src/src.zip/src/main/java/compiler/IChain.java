package compiler;

import compiler.token.ETokenTypes;

/***
 * Implemented by ILink
 * @author dgb
 * A super interface to build ILink classes
 */
public interface IChain {
	public void setTokenType(ETokenTypes tt);
	public IChain setNextLink(Class<? extends IChain> next, ETokenTypes child);
}
