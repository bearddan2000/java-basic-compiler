package compiler.lexer.chain;

import java.util.ArrayList;

import org.apache.log4j.Logger;

import compiler.ChainFactory;
import compiler.IChain;
import compiler.error.IllegalCharError;
import compiler.lexer.Lexer;
import compiler.lexer.Position;
import compiler.token.ETokenTypes;
import compiler.token.Token;
/***
 * Holds common functions for ILink classes
 * @author dgb
 * COR and template patterns
 */
public abstract class BaseLink implements ILink{

	// logger for log4j
	static final Logger logger = Logger.getLogger(BaseLink.class);

	protected IChain nextLink = null;
	protected ETokenTypes type = null;

	public BaseLink() {
		// TODO Auto-generated constructor stub
	}

	public BaseLink(ETokenTypes child) {
		// TODO Auto-generated constructor stub
		this.type = child;
	}
	/***.
	 * Setter for token type
	 * @param t token type to be set
	 */
	public void setTokenType(ETokenTypes t) {
		this.type = t;
	}
	/***
	 * Instanciates a class that extends ILink
	 * Sets the class' token type.
	 * Sets the next link in the chain.
	 * @param next the next link in the chain
	 * @param child the token type for the next link
	 * @return the next link instance
	 */
	public IChain setNextLink(Class<? extends IChain> next, ETokenTypes child) {
		this.nextLink = ChainFactory.createChainLink(next);
		this.nextLink.setTokenType(child);
		return this.nextLink;
	}
	/***
	 * Checks if next link is null
	 * if not call eval passing along the params
	 * else flag as an illegal char error
	 * @param obj Lexer object 
	 * @param tokenList ArrayList of tokens
	 */
	protected void tailEval(Lexer obj, ArrayList<Token> tokenList) {
		if(nextLink != null)
			((ILink)nextLink).eval(obj, tokenList);
		else
		{
			Position pos = obj.getPos().copy();
			char c = obj.getCurrentChar();
			obj.advance();
			IllegalCharError err = new IllegalCharError(pos, obj.getPos(), "'" + c + "'");
			System.out.println(err.toString());
			logger.error(err.toString());
		}
	}
}
