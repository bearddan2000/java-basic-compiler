package compiler.lexer.chain;

import compiler.lexer.Lexer;
import compiler.token.ETokenTypes;
import compiler.token.Token;

import java.util.ArrayList;

import org.apache.log4j.Logger;

/***
 * Captures integers and float tokens
 * @author dgb
 * COR and template patterns
 */

public class FactorLink extends BaseLink implements ILink{	
	// logger for log4j
	static final Logger logger = Logger.getLogger(FactorLink.class);
	
	public FactorLink() { super(); }
	public FactorLink(ETokenTypes child) { super(child);}
	
	/***
	 * Check current char is a number.
	 * If is parse for either int or float.
	 * Else call base class
	 * @param obj Lexer object
	 * @param tokenList ArrayList of tokens
	 */	
	public void eval(Lexer obj, ArrayList<Token> tokenList) {
		
		if(Character.isDigit(obj.getCurrentChar())) {
			Token token = this.makeNumber(obj);
			tokenList.add(token);
		}
		else
			super.tailEval(obj, tokenList);
	}

	private Token makeNumber(Lexer obj)
	{
        String num_str = "";
        int dot_count = 0;
		char c = obj.getCurrentChar();
		
		while(Character.isDigit(c) || c == '.') {
            if(c == '.') { // this marks a float or possible error
                if(dot_count == 1) break;
                dot_count++;
                num_str += ".";
            }
            else
                num_str += c;
            obj.advance();
			c = obj.getCurrentChar();
		};

        if(dot_count == 0)
            return new Token(ETokenTypes.TT_INT, Integer.valueOf(num_str));
        else
            return new Token(ETokenTypes.TT_FLOAT, Float.valueOf(num_str));
	}
}