package compiler.lexer.chain;

import compiler.lexer.Lexer;
import compiler.token.ETokenTypes;
import compiler.token.Token;

import java.util.ArrayList;

import org.apache.log4j.Logger;

/***
 * Used to capture +,-,*,/,( and )
 * @author dgb
 * COR and template patterns
 */
public class OpLink extends BaseLink implements ILink{	
	// logger for log4j
	static final Logger logger = Logger.getLogger(OpLink.class);
	
	public OpLink() { super(); }
	public OpLink(ETokenTypes child) { super(child);}
	
	/***
	 * Capture operation
	 * advance the Lexer
	 */
	public void eval(Lexer obj, ArrayList<Token> tokenList) {
		char condition = type.getVal().charAt(0);
		if(condition == obj.getCurrentChar() )
		{
			Token token = new Token(super.type);
			tokenList.add(token);
			obj.advance();
		}
		else
			super.tailEval(obj, tokenList);
	}
}