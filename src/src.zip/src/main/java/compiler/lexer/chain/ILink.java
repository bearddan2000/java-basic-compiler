package compiler.lexer.chain;

import java.util.ArrayList;

import compiler.IChain;
import compiler.lexer.Lexer;
import compiler.token.Token;
/***
 * Used to chain token types
 * inherits from compiler.IChain
 * @author dgb
 * COR pattern
 */
public interface ILink extends IChain{
	public void eval(Lexer obj, ArrayList<Token> tokenList);
}
