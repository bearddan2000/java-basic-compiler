package compiler.lexer;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import org.apache.log4j.Logger;

import compiler.App;
import compiler.lexer.chain.*;
import compiler.token.ETokenTypes;
import compiler.token.Token;
/***
 * Divides string into tokens
 * @author dgb
 * uses patterns iterative and chain of responsibility (COR)
 */
public class Lexer {
	Method fn;
	String text;
	Position pos;
	char current_char;

	// root node for the COR
	ILink decision;

	// logger for log4j
	static final Logger logger = Logger.getLogger(Lexer.class);

	public Lexer(Method fn, String text) {
		// TODO Auto-generated constructor stub

		this.fn = fn;
		this.text = text;
		this.pos = new Position(-1, 0, -1, fn, text);

		// '\0' is char version of null
		this.current_char = '\0';
		this.initDecisionTree();
		this.advance();
	}

	private void initDecisionTree() {
		decision = new NonOpLink(ETokenTypes.TT_TAB);
		decision.setNextLink(FactorLink.class, null)
		.setNextLink(OpLink.class, ETokenTypes.TT_PLUS)
		.setNextLink(OpLink.class, ETokenTypes.TT_MINUS)
		.setNextLink(OpLink.class, ETokenTypes.TT_MUL)
		.setNextLink(OpLink.class, ETokenTypes.TT_DIV)
		.setNextLink(OpLink.class, ETokenTypes.TT_MOD)
		.setNextLink(OpLink.class, ETokenTypes.TT_POW)
		.setNextLink(OpLink.class, ETokenTypes.TT_ROOT)
		.setNextLink(OpLink.class, ETokenTypes.TT_FACTORIAL)
		.setNextLink(OpLink.class, ETokenTypes.TT_LPAREN)
		.setNextLink(OpLink.class, ETokenTypes.TT_RPAREN);		
	}
	/***
	 * getter for position in string
	 * @return Position
	 */
	public Position getPos() {
		return pos;
	}
	/***
	 * getter for current char in string
	 * @return char
	 */
	public char getCurrentChar() {
		return current_char;
	}

	/***
	 * calls advance on Position obj
	 * sets current char
	 * @see compiler.lexer.Position
	 */
	public void advance() {
		this.pos.advance(this.current_char);
		this.current_char = (this.pos.getIdx() < this.text.length()) ?
				this.text.charAt(this.pos.getIdx()) : '\0';
	}

	/***
	 * We iterate the current char by our COR
	 * @return ArrayList<Token>
	 */
	public ArrayList<Token> makeToken() {

		ArrayList<Token> tokenList = new ArrayList<Token>();

		while(this.current_char != '\0')
			this.decision.eval(this, tokenList);

		tokenList.add(new Token(ETokenTypes.TT_EOF, this.pos));		

		
		/*
		 * for(ListIterator<Token> itr = tokenList.listIterator(); itr.hasNext(); )
		 * System.out.format("%s ", itr.next().toString());
		 */
		 
		return tokenList;
	}

}
