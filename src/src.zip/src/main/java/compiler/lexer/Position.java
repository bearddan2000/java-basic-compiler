package compiler.lexer;

import java.lang.reflect.Method;

import org.apache.log4j.Logger;

/***
 * Pinpoints exact location for errors and iteration
 * @author dgb
 *
 */

public class Position {
	// logger for log4j
	static final Logger logger = Logger.getLogger(Position.class);
	
	int idx, ln, col;

	Method fn; 
	String ftxt;

	public Position(int idx, int ln, int col, Method fn, String ftxt) {
		// TODO Auto-generated constructor stub
		this.col = col;
		this.fn = fn;
		this.ftxt = ftxt;
		this.idx = idx;
		this.ln = ln;
	} 
	public Position() {
		// TODO Auto-generated constructor stub
		this.col = 0;
		this.fn = null;
		this.ftxt = "";
		this.idx = 0;
		this.ln = 0;
	}
	/***
	 * getter for current char in the input
	 * @return int
	 */
	public int getIdx() {
		return idx;
	}

	/***
	 * ??? 
	 * @return java.lang.reflect.Method
	 */
	public Method getFn() {	return fn;	}
	/***
	 * getter
	 * @return int
	 */
	public int getLn() {
		return ln;
	}
	/***
	 * advance to next char unless its EOL
	 * @param current_char char in the input
	 * @return Position
	 * @see compiler.lexer.Position
	 */
	
	public Position advance(char current_char) {
		this.idx+=1;
		this.col+=1;

		if(current_char == '\n') {
			this.ln+=1;
			this.col = 0;
		}
		return this;		
	}
	/***
	 * Basically a clone function
	 * @return Position
	 * @see compiler.lexer.Position
	 */
	public Position copy() {
		return new Position(this.idx, this.ln, this.col, this.fn, this.ftxt);
	}
	
	@Override
	public String toString() {
		return "Position [idx=" + idx + ", ln=" + ln + ", col=" + col + "]";
	}
}
