package compiler.result;

import compiler.error.BaseError;
import compiler.error.RuntimeError;
import compiler.interpreter.Context;
import compiler.lexer.Position;
import compiler.token.ETokenTypes;

public class Number {
	Object value = null;
	BaseError e = null;
	Context context = null;
	Position pos_start, pos_end;

	public Number() {
		// TODO Auto-generated constructor stub
	}
	
	public Number(Object value) {
		// TODO Auto-generated constructor stub
		this.value = value;
		this.pos_start = null;
		this.pos_end = null;
	}

	public Object getValue() {
		return value;
	}
	public Position getPos_start() {
		return pos_start;
	}

	public Position getPos_end() {
		return pos_end;
	}

	public BaseError getError() {
		return e;
	}

	public Number setContext(Context context) {
		this.context = context;
		return this;
	}

	public Number setPos(Position pos_start, Position pos_end) {
		this.pos_start = pos_start;
		this.pos_end = pos_end;
		return this;
	}

	@Override
	public String toString() {
		return "" + this.value;
	}
}
