package compiler.result;

import compiler.error.BaseError;
import compiler.parser.node.INode;

public class ParseResult implements IResult{

	private BaseError error = null;
	private INode node;
	
	public ParseResult() {}
	
	public ParseResult(BaseError e, INode node) {
		// TODO Auto-generated constructor stub
		this.error = e;
		this.node = node;
	}
	@Override
	public void setError(BaseError error) {
		this.error = error;
	}

	@Override
	public BaseError getError() {
		return this.error;
	}
	
	public void setNode(INode node) {
		this.node = node;
	}
	public INode getNode() {
		// TODO Auto-generated method stub
		return this.node;
	}

	public Object register(Object res) {
		if(res instanceof ParseResult){
			ParseResult tmp = (ParseResult) res;
			if(tmp.getError() != null)
				this.error = tmp.getError();
			return tmp.getNode();
		}
		return res;
	}

	public IResult success(INode node) { this.node = node; return this;}
	
	@Override
	public IResult failure(BaseError e) { this.error = e; return this;}

}
