package compiler.result;

import compiler.error.BaseError;
import compiler.parser.node.INode;

public class RuntimeResult implements IResult{

	private BaseError error;
	private compiler.result.Number value;

	public RuntimeResult() {
		// TODO Auto-generated constructor stub
	}

	public Object register(compiler.result.Number res) {
		// TODO Auto-generated method stub
		if(res.getError() != null)
			this.error = res.getError();
		return res.getValue();
	}
	@Override
	public Object register(Object res) {
		if(res instanceof compiler.result.Number)
			return this.register((compiler.result.Number)res);
		else if(res instanceof RuntimeResult) {
			RuntimeResult rt = (RuntimeResult)res;
			if(rt.getError() != null)
				this.error = rt.getError();
		}
		return res;
	}
	public IResult success(compiler.result.Number number) {
		// TODO Auto-generated method stub
		this.value = number;
		return this;
	}
	@Override
	public IResult failure(BaseError e) {
		// TODO Auto-generated method stub
		this.error = e;
		return this;
	}

	@Override
	public void setError(BaseError error) {
		// TODO Auto-generated method stub
		this.error = error;
	}

	@Override
	public BaseError getError() {
		// TODO Auto-generated method stub
		return this.error;
	}

	public compiler.result.Number getValue() {
		return value;
	}

	@Override
	public String toString() {
		return "RuntimeResult [value=" + value + "]";
	}
}
