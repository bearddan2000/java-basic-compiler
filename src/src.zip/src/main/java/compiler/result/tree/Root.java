package compiler.result.tree;

import compiler.token.ETokenTypes;

public class Root {
	Lvl1 left, right;
	
	public Root() {
		// TODO Auto-generated constructor stub
		this.left = new Lvl1();
		this.right = new Lvl1();
	}
	
	public compiler.result.Number eval(Object i, ETokenTypes tt){
		Object val = ((compiler.result.Number)i).getValue();
		if(val instanceof Integer)
			return this.left.eval((Integer)val, tt);
		else if(val instanceof Float)
			return this.right.eval((Float)val, tt);
		return null;
	}

	public compiler.result.Number eval(Object i, Object j, ETokenTypes tt)
	{
		Object val = ((compiler.result.Number)i).getValue();
		Object other = ((compiler.result.Number)j).getValue();
		if(val instanceof Integer)
			return this.left.eval((Integer)val, other, tt);
		else if(val instanceof Float)
			return this.right.eval((Float)val, other, tt);
		return null;		
	}
}
