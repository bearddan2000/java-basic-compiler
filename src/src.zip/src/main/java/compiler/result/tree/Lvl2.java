package compiler.result.tree;

import compiler.result.tree.strategy.ILink;
import compiler.token.ETokenTypes;

public class Lvl2 {

	private ILink link = null;
	
	private void setLink(ETokenTypes eTokenTypes) {
		switch(eTokenTypes) {
		case TT_PLUS: this.link = new compiler.result.tree.strategy.Add(); break;
		case TT_MINUS: this.link = new compiler.result.tree.strategy.Sub(); break;
		case TT_MUL: this.link = new compiler.result.tree.strategy.Multiply(); break;
		case TT_DIV: this.link = new compiler.result.tree.strategy.Div(); break;
		case TT_POW: this.link = new compiler.result.tree.strategy.Pow(); break;
		case TT_ROOT: this.link = new compiler.result.tree.strategy.Root(); break;
		case TT_MOD: this.link = new compiler.result.tree.strategy.Mod(); break;
		default: return;
		}
	}

	public compiler.result.Number eval(Integer i, Integer j, ETokenTypes tt) {
		this.setLink(tt);
		if(link == null)
			return null;
		
		return link.eval(i, j);
	}

	public compiler.result.Number eval(Integer i, Float j, ETokenTypes tt, boolean IsSwapt) {
		this.setLink(tt);
		if(link == null)
			return null;
		
		if(IsSwapt)
			return link.eval(j, i);
		return link.eval(i, j);
	}
	
	public compiler.result.Number eval(Float i, Float j, ETokenTypes tt) {
		this.setLink(tt);
		if(link == null)
			return null;
		
		return link.eval(i, j);
	}
}
