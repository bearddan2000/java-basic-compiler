package compiler.result.tree.strategy;

public interface ILink{
	public compiler.result.Number eval(Integer i, Integer j);
	public compiler.result.Number eval(Float i, Integer j);
	public compiler.result.Number eval(Integer i, Float j);
	public compiler.result.Number eval(Float i, Float j);
}
