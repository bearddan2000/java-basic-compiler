package compiler.result.tree.strategy;

import compiler.result.Number;

public class Root implements ILink {

	compiler.result.Number num;
	
	@Override
	public Number eval(Integer i, Integer j) {
		// TODO Auto-generated method stub
		Double exp = 1/Double.valueOf(j);
		Double base = Double.valueOf(i);
		num = new compiler.result.Number(Math.pow(base, exp));
		return num;
	}

	@Override
	public Number eval(Float i, Integer j) {
		// TODO Auto-generated method stub
		Double exp = 1/Double.valueOf(j);
		Double base = Double.valueOf(i);
		num = new compiler.result.Number(Math.pow(base, exp));
		return num;
	}

	@Override
	public Number eval(Integer i, Float j) {
		// TODO Auto-generated method stub
		Double exp = 1/Double.valueOf(j);
		Double base = Double.valueOf(i);
		num = new compiler.result.Number(Math.pow(base, exp));
		return num;
	}

	@Override
	public Number eval(Float i, Float j) {
		// TODO Auto-generated method stub
		Double exp = 1/Double.valueOf(j);
		Double base = Double.valueOf(i);
		num = new compiler.result.Number(Math.pow(base, exp));
		return num;
	}

}
