package compiler.result.tree;

import compiler.result.Number;
import compiler.token.ETokenTypes;

public class Lvl1 {
	compiler.result.Number num = null;
	Lvl2 left, right;
	
	public compiler.result.Number eval(Integer i, ETokenTypes tt){
		if(tt == ETokenTypes.TT_MINUS)
			num = new compiler.result.Number(i*-1);
		else if(tt == ETokenTypes.TT_FACTORIAL) {
			Integer result = 1;
			for(int x=1;x<i+1;x++)
				result *= x;
			num = new compiler.result.Number(result);
		}
		else
			num = new compiler.result.Number(i);
		return num;
	}
	
	public compiler.result.Number eval(Float i, ETokenTypes tt){
		if(tt == ETokenTypes.TT_MINUS)
			num = new compiler.result.Number(i*-1.0);
		else if(tt == ETokenTypes.TT_FACTORIAL) {
			Float result = Float.valueOf(1);
			for(float x=1;x<i+1;x++)
				result *= x;
			num = new compiler.result.Number(result);
		}
		else
			num = new compiler.result.Number(i);
		return num;
	}
	
	public compiler.result.Number eval(Integer i, Object j, ETokenTypes tt) {
		this.left = new Lvl2();
		
		if(j instanceof Integer)
			num = this.left.eval(i, (Integer)j, tt);
		else if(j instanceof Float)
			num = this.left.eval(i, (Float)j, tt, false);
		else if(j instanceof Double)
			num = this.left.eval(i, ((Double)j).floatValue(), tt, false);
		return num;
	}
	
	public compiler.result.Number eval(Float i, Object j, ETokenTypes tt) {
		this.right = new Lvl2();
		
		if(j instanceof Integer)
			num = this.right.eval((Integer)j, i, tt, true);
		else if(j instanceof Float)
			num = this.right.eval(i, (Float)j, tt);
		else if(j instanceof Double)
			num = this.right.eval(i, ((Double)j).floatValue(), tt);
		return num;
	}

}
