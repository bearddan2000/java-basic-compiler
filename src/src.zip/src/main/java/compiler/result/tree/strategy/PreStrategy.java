package compiler.result.tree.strategy;

import java.util.function.Function;

public class PreStrategy<T> {

	Function<T, compiler.result.Number> delegate;
	
	public void setDelegate(Function<T, compiler.result.Number> d) {
		this.delegate = d;
	}
	
	public compiler.result.Number eval(T i)
	{
		return this.delegate.apply(i);
	}

}
