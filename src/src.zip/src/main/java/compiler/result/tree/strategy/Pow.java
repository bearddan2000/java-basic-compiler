package compiler.result.tree.strategy;

import compiler.result.Number;

public class Pow implements ILink {

	compiler.result.Number num;
	
	@Override
	public Number eval(Integer i, Integer j) {
		// TODO Auto-generated method stub
		num = new compiler.result.Number(Math.pow(i, j));
		return num;
	}

	@Override
	public Number eval(Float i, Integer j) {
		// TODO Auto-generated method stub
		num = new compiler.result.Number(Math.pow(i, j));
		return num;
	}

	@Override
	public Number eval(Integer i, Float j) {
		// TODO Auto-generated method stub
		num = new compiler.result.Number(Math.pow(i, j));
		return num;
	}

	@Override
	public Number eval(Float i, Float j) {
		// TODO Auto-generated method stub
		num = new compiler.result.Number(Math.pow(i, j));
		return num;
	}

}
