
package compiler.result.tree.strategy;

/***
 * Subtracts compiler.result.Number
 * @author dgb
 * Strategy pattern
 */
public class Sub implements ILink {

	compiler.result.Number num = null;

	/***
	 * Subtracts Integers
	 */
	@Override
	public compiler.result.Number eval(Integer i, Integer j) {
		num = new compiler.result.Number(i-j);
		return num;
	}

	/***
	 * Subtracts Float and Integer
	 */
	@Override
	public compiler.result.Number eval(Float i, Integer j) {
		num = new compiler.result.Number(i-j);
		return num;
	}
	/***
	 * Subtracts Integer and Float
	 */
	@Override
	public compiler.result.Number eval(Integer i, Float j) {
		num = new compiler.result.Number(i-j);
		return num;
	}
	/***
	 * Subtracts Floats
	 */
	@Override
	public compiler.result.Number eval(Float i, Float j) {
		num = new compiler.result.Number(i-j);
		return num;
	}
}
