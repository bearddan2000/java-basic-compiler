package compiler.result.tree.strategy;

/***
 * Adds compiler.result.Number
 * @author dgb
 * Strategy pattern
 */
public class Add implements ILink {

	compiler.result.Number num = null;

	/***
	 * Adds Integers
	 */
	@Override
	public compiler.result.Number eval(Integer i, Integer j) {
		num = new compiler.result.Number(i+j);
		return num;
	}

	/***
	 * Adds Float and Integer
	 */
	@Override
	public compiler.result.Number eval(Float i, Integer j) {
		num = new compiler.result.Number(i+j);
		return num;
	}
	/***
	 * Adds Integer and Float
	 */
	@Override
	public compiler.result.Number eval(Integer i, Float j) {
		num = new compiler.result.Number(i+j);
		return num;
	}
	/***
	 * Adds Floats
	 */
	@Override
	public compiler.result.Number eval(Float i, Float j) {
		num = new compiler.result.Number(i+j);
		return num;
	}
}
