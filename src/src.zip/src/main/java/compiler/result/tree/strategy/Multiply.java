
package compiler.result.tree.strategy;

/***
 * Multiply compiler.result.Number
 * @author dgb
 * Strategy pattern
 */
public class Multiply implements ILink {

	compiler.result.Number num = null;

	/***
	 * Multiply Integers
	 */
	@Override
	public compiler.result.Number eval(Integer i, Integer j) {
		num = new compiler.result.Number(i*j);
		return num;
	}

	/***
	 * Multiply Float and Integer
	 */
	@Override
	public compiler.result.Number eval(Float i, Integer j) {
		num = new compiler.result.Number(i*j);
		return num;
	}
	/***
	 * Multiply Integer and Float
	 */
	@Override
	public compiler.result.Number eval(Integer i, Float j) {
		num = new compiler.result.Number(i*j);
		return num;
	}
	/***
	 * Multiply Floats
	 */
	@Override
	public compiler.result.Number eval(Float i, Float j) {
		num = new compiler.result.Number(i*j);
		return num;
	}
}
