package compiler.result.tree.strategy;

import compiler.error.BaseError;
import compiler.error.RuntimeError;
import compiler.interpreter.Context;
import compiler.lexer.Position;
import compiler.result.Number;

public class Div implements ILink {

	BaseError e = null;
	compiler.result.Number num = null;
	Context context = new Context("<program>");

	private void initError() {
		this.num = new Number();
		Position p = new Position();
		e = new RuntimeError(p, p, "Div by zero", this.context);
		System.err.println(e.toString());
	}

	@Override
	public compiler.result.Number eval(Integer i, Integer j) {

		if(j == 0)
			this.initError();
		else
			num = new compiler.result.Number(i/j);

		return num;
	}

	@Override
	public compiler.result.Number eval(Float i, Integer j) {

		if(j == 0)
			this.initError();
		else
			num = new compiler.result.Number(i/j);

		return num;
	}

	@Override
	public compiler.result.Number eval(Integer i, Float j) {

		if(j == 0)
			this.initError();
		else
			num = new compiler.result.Number(i/j);

		return num;
	}

	@Override
	public compiler.result.Number eval(Float i, Float j) {

		if(j == 0)
			this.initError();
		else
			num = new compiler.result.Number(i/j);

		return num;
	}

}
