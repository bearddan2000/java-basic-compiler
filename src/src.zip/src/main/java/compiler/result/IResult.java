package compiler.result;

import compiler.error.BaseError;
import compiler.parser.node.INode;

public interface IResult {
	public Object register(Object res);
	public IResult failure(BaseError e);
	public void setError(BaseError error);
	public BaseError getError();
}
