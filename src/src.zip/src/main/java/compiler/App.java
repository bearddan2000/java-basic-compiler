package compiler;

import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

import compiler.interpreter.Context;
import compiler.interpreter.Interpreter;
import compiler.lexer.Lexer;
import compiler.parser.Parser;
import compiler.result.ParseResult;
import compiler.token.Token;
/***
 * Compiler for a basic like compiler
 * @author dgb
 * @since 9/1/2020
 */
public class App {

	// logger for log4j
	static final Logger logger = Logger.getLogger(App.class);
	private static void interactive() {
		Scanner input = new Scanner(System.in);
		final int maxPerRow = 5;
		while(true) {
			int i = 1;
			StringBuilder sb = new StringBuilder();
			for(EExamples e : EExamples.values()) {
				int flag = i % maxPerRow;
				if(flag != 0) {
					if(sb.length() > 0)
						sb.append("\t");
					sb.append(String.format("%d] %s", i, e.getLabel()));
				}
				else {
					sb.append(String.format("\t%d] %s", i, e.getLabel()));
					System.out.println(sb.toString());
					sb = new StringBuilder();
				}
				i++;
			}
			System.out.println(sb.toString());
			System.out.println("0] To exit");
			System.out.println("make a selection > ");
			int selection = input.nextInt();
			input.nextLine();
			if(selection == 0) break;
			else if(selection > i) {
				System.out.println("invalid selection > " + selection);
				System.out.println();
			}
			else {
				EExamples e = EExamples.values()[selection];
				System.out.println("calculating > " + e.getExpression());
				System.out.println("answer > " + e.calc());
			}
		}
		input.close();
	}
	private static void test() {
		for(EExamples e : EExamples.values()) {
			System.out.println(
					String.format("%s\tequation: %s\tresult: %s", e.getLabel()
							, e.getExpression()
							, e.calc()));			
		}	
	}
	private static void usage() {
		System.out.println("Usage");
		System.out.println("-i interactive");
		System.out.println("-t test all expressions");
	}
	/***
	 * Entrypoint
	 * @param args
	 */
	public static void main(String[] args) {

		// TODO Auto-generated method stub
		if(args.length == 1) {
			switch(args[0]) {
			case "-i": App.interactive(); break;
			case "-t": App.test(); break;
			}
		}
		else
			App.usage();
	}
	

}
