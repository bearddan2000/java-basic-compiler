package compiler.error;

import org.apache.log4j.Logger;

import compiler.interpreter.Context;
import compiler.lexer.Position;
/***
 * Catches division by zero errors
 * @author dgb
 * Used by RuntimeResults
 * Template pattern
 */
public class RuntimeError extends BaseError {
	// logger for log4j
	static final Logger logger = Logger.getLogger(RuntimeError.class);

	private Context context;
	
	public RuntimeError(Position pos_start, Position pos_end, String details, Context context) {
		super(pos_start, pos_end, "Runtime error", details);
		super.child = this.getClass();
		this.context = context;
		// TODO Auto-generated constructor stub
	}

	private String generateTraceback() {

		StringBuilder result = new StringBuilder();
		Position pos = super.pos_start;
		Context ctx = this.context;

		while (ctx != null) {
			result.append(String.format("  File %s, line %d, in %s\n",pos.getFn().toGenericString(), pos.getLn() + 1, ctx.getDisplayName()));
			
			pos = ctx.getParentEntryPosition();
			ctx = ctx.getParent();
		}
		result.append("Traceback (most recent call last):\n");
		return result.toString();
	}
}
