package compiler.error;

import org.apache.log4j.Logger;

import compiler.App;
import compiler.lexer.Position;
/***
 * Base class for our errors
 * @author dgb
 * Template pattern
 */
public class BaseError{

	// logger for log4j
    static final Logger logger = Logger.getLogger(BaseError.class);
    
	protected Class<? extends BaseError> child;
	protected String details, error_name;
	protected Position pos_start, pos_end;

	public BaseError(Position pos_start, Position pos_end, String error_name, String details) {
		this.child = null;
		this.init(pos_end, pos_end, error_name, details);
	}

	private void init(Position pos_start, Position pos_end,  String error_name, String details) {
		this.details = details;
		this.error_name = error_name;
		this.pos_end = pos_end;
		this.pos_start = pos_start;		
	}
	
	private String string_with_arrows(/*String text, Position pos_start, Position pos_end*/) {	    
		String result = "";
/*
		    # Calculate indices
		    idx_start = max(text.rfind('\n', 0, pos_start.idx), 0)
		    idx_end = text.find('\n', idx_start + 1)
		    if idx_end < 0: idx_end = len(text)
		    
		    # Generate each line
		    line_count = pos_end.ln - pos_start.ln + 1
		    for i in range(line_count):
		        # Calculate line columns
		        line = text[idx_start:idx_end]
		        col_start = pos_start.col if i == 0 else 0
		        col_end = pos_end.col if i == line_count - 1 else len(line) - 1

		        # Append to result
		        result += line + '\n'
		        result += ' ' * col_start + '^' * (col_end - col_start)

		        # Re-calculate indices
		        idx_start = idx_end
		        idx_end = text.find('\n', idx_start + 1)
		        if idx_end < 0: idx_end = len(text)

		    return result.replace('\t', '')
		    */
		return "";
	}
	
	@Override
	public String toString() {
		String label = (child == null) ? this.getClass().getSimpleName() : child.getClass().getSimpleName();
		label += " [details=" + details + ", error_name=" + error_name + ", pos_start=" + pos_start
				+ ", pos_end=" + pos_end + "]";
		
		label += "\nFile <stdin>, line: " + pos_start.getIdx() + 1;
		
		//string_with_arrows(self.pos_start.ftxt, self.pos_start, self.pos_end)
		label += "\n\n" + this.string_with_arrows();
		
		return label;
	}
	
}
