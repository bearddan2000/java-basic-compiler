package compiler.error;

import org.apache.log4j.Logger;
import compiler.lexer.Position;

/***
 * Catches any characters that may be in the wrong position
 * @author dgb
 * Used in Lexer class
 * Template pattern
 */
public class IllegalCharError extends BaseError {

	// logger for log4j
	static final Logger logger = Logger.getLogger(IllegalCharError.class);
	
	public IllegalCharError(Position pos_start, Position pos_end, String details) {
		super(pos_start, pos_end, "IllegalCharError", details);
		super.child = this.getClass();
		// TODO Auto-generated constructor stub
	}

}
