package compiler.error;

import org.apache.log4j.Logger;

import compiler.lexer.Position;
/***
 * Catches invalid operators
 * @author dgb
 * Used by Lexer class
 * Template pattern
 */
public class InvalidSyntaxError extends BaseError {
	// logger for log4j
	static final Logger logger = Logger.getLogger(InvalidSyntaxError.class);

	public InvalidSyntaxError(Position pos_start, Position pos_end, String details) {
		super(pos_start, pos_end, "Invalid Syntax", details);
		super.child = this.getClass();
		// TODO Auto-generated constructor stub
	}

	public InvalidSyntaxError() {
		super(new Position(), new Position(), "Invalid Syntax", "");		
		super.child = this.getClass();
		// TODO Auto-generated constructor stub
	}

}
