package compiler.interpreter;

import org.apache.log4j.Logger;

import compiler.parser.node.INode;
/***
 * Turns tokens into expressions
 * by navigating abstract syntax tree
 * @author dgb
 * Visitor pattern
 */
public class Interpreter {
	// logger for log4j
	static final Logger logger = Logger.getLogger(Interpreter.class);

	/***
	 * Calls the overriden visit function on nodes
	 * @param node any INode class
	 * @param context for future use
	 * @return compiler.result.Number
	 */
	public compiler.result.Number visit(INode node, Context context) {
		return node.visit(node, context, this);
	}
}
