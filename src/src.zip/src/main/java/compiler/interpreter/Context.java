package compiler.interpreter;

import org.apache.log4j.Logger;

import compiler.lexer.Position;
/***
 * For future use 
 * @author dgb
 *
 */
public class Context {
	// logger for log4j
	static final Logger logger = Logger.getLogger(Context.class);

	private String displayName;
	private Context parent; 
	private Position parentEntryPosition;


	public Context(String displayName) {
		// TODO Auto-generated constructor stub
		this.displayName = displayName;
	}

	public Context(String displayName, Context parent, Position parentEntryPosition) {
		// TODO Auto-generated constructor stub
		this.displayName = displayName;
		this.parent = parent;
		this.parentEntryPosition = parentEntryPosition;
	}
	/***
	 * getter
	 * @return String
	 */
	public String getDisplayName() {
		return displayName;
	}
	/***
	 * getter
	 * @return Context
	 */
	public Context getParent() {
		return parent;
	}
	/***
	 * getter
	 * @return compiler.lexer.Position
	 */
	public Position getParentEntryPosition() {
		return parentEntryPosition;
	}

}
