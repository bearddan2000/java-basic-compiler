package compiler.token;

public enum ETokenTypes{
    TT_TAB("\t", "TAB"),
	TT_INT("INT"), 
	TT_FLOAT("FLOAT"), 
	TT_PLUS("+", "PLUS"), 
	TT_MINUS("-", "MINUS"), 
	TT_MUL("*", "MUL"), 
	TT_DIV("/", "DIV"), 
	TT_MOD("%", "MOD"),
	TT_POW("^", "POW"),
	TT_ROOT("V", "ROOT"),
	TT_FACTORIAL("!", "EXP"),
	TT_LPAREN("(", "LPAREN"), 
	TT_RPAREN(")", "RPAREN"),
	TT_EOF("\n", "EOF");	

	private String val = "";
	private String label;

	ETokenTypes(String v, String l) {
		// TODO Auto-generated constructor stub
		val = v;
		label = l;
	}
	
	ETokenTypes(String l) {
		// TODO Auto-generated constructor stub
		label = l; 
	}
	
	public String getVal() {
		return val;
	}
	
	public String getLabel() {
		return label;
	}
}
