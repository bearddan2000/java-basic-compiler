package compiler.token;

import compiler.lexer.Position;

public class Token {

	ETokenTypes type; 
	Object value = null;
	Position pos_start, pos_end;
	
	public Token(ETokenTypes type) {
		// TODO Auto-generated constructor stub
		this.type = type;
		this.value = type.getVal();
	}

	public Token(ETokenTypes type, Object value) {
		// TODO Auto-generated constructor stub
		this.init(type, value);
	}

	public Token(ETokenTypes type, Object value, Position pos_start, Position pos_end) {
		// TODO Auto-generated constructor stub
		this.init(type, value);

		if(pos_start != null) {
			this.pos_start = pos_start.copy();
			this.pos_end = pos_start.copy();
			this.pos_end.advance('\0');
		}

		if(pos_end != null)
			this.pos_end = pos_end;
		
	}
	
	private void init(ETokenTypes type, Object value) {
		this.type = type;
		this.value = value;		
	}

	public ETokenTypes getType() {
		return type;
	}

	public Position getPos_start() {
		return pos_start;
	}

	public Position getPos_end() {
		return pos_end;
	}

	public Object getValue() {
		return value;
	}

	@Override
	public String toString() {
		String results = String.format("[%s:", type);
		results += String.format("%s]", value);
		return results;
	}

}
