package compiler;

import org.apache.log4j.Logger;

/***
 * Creates link instances for COR pattern
 * @author dgb
 * Factory pattern
 */
public class ChainFactory {

	// logger for log4j
	static final Logger logger = Logger.getLogger(ChainFactory.class);

	private static <T> T build(Class<? extends T> link) {
		Class c;
		T nextLink = null;
		try {
			link.getClass();
			c = Class.forName(link.getName());
			nextLink = (T) c.newInstance();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
			e.printStackTrace();
		}
		return nextLink;		
	}
	/***
	 * Generic factory for any link
	 * @param link class that implements IChain
	 * @return IChain link
	 */
	public static IChain createChainLink(Class<? extends IChain> link) {
		IChain nextLink = ChainFactory.build(link);
		return nextLink;
	}
}
