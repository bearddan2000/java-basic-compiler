package compiler.parser;

import org.apache.log4j.Logger;

import compiler.error.BaseError;
import compiler.error.InvalidSyntaxError;
import compiler.parser.node.INode;
import compiler.result.ParseResult;
import compiler.token.ETokenTypes;
import compiler.token.Token;
/***
 * Checks for + and -
 * @author dgb
 * COR pattern
 */
public class FactorFactory{
	// logger for log4j
	static final Logger logger = Logger.getLogger(FactorFactory.class);

	public static Object factor(Parser parser, Token token, ParseResult res) {
		return FactorFactory.postExpression(parser, token, res);
	}
	private static Object postExpression(Parser parser, Token token, ParseResult res)
	{
		Token peek = parser.peek();
		if(peek.getType() == ETokenTypes.TT_FACTORIAL &&
				token.getType() == ETokenTypes.TT_INT ||
				token.getType() == ETokenTypes.TT_FLOAT	) {
			INode factor = (INode)res.register(new compiler.parser.node.NumberNode(token));
			res.register(parser.advance());
			if(parser.hasError(res)) return res;
			return res.success(new compiler.parser.node.UniOpNode(peek, factor));			
		}
		return FactorFactory.operatorExpression(parser, token, res);
	}
	/***
	 * @return signed number
	 */
	private static Object operatorExpression(Parser parser, Token token, ParseResult res) {
		if(token.getType() == ETokenTypes.TT_PLUS || 
				token.getType() == ETokenTypes.TT_MINUS) {
			res.register(parser.advance());
			INode factor = (INode)res.register(parser.factor());
			if(parser.hasError(res)) return res;
			return res.success(new compiler.parser.node.UniOpNode(token, factor));
		}		
		return FactorFactory.numberExpression(parser, token, res);
	}
	/***
	 * Look for int or float
	 */
	private static Object numberExpression(Parser parser, Token token, ParseResult res) {
		if(token.getType() == ETokenTypes.TT_INT ||
				token.getType() == ETokenTypes.TT_FLOAT) {
			res.register(parser.advance());
			return res.success(new compiler.parser.node.NumberNode(token));
		}
		return FactorFactory.groupExpression(parser, token, res);
	}
	/***
	 * Check for matching paranthesis
	 */
	private static Object groupExpression(Parser parser, Token token, ParseResult res) {
		if(token.getType() == ETokenTypes.TT_LPAREN) {
			res.register(parser.advance());
			INode expr = (INode)res.register(parser.exp());
			if(parser.hasError(res)) return res;
			if(parser.current_tok.getType() == ETokenTypes.TT_RPAREN){
				res.register(parser.advance());
				return res.success(expr);
			}
			else {
				BaseError e = new InvalidSyntaxError(
						parser.current_tok.getPos_start(), parser.current_tok.getPos_end(),
						"Expected ')'"
						);
				String msg = e.toString();
				System.err.println(msg);
				logger.warn(msg);
				return res.failure(e);
			}
		}		
		return FactorFactory.endExpression(parser, token, res);
	}

	/***
	 * returns null or top of the tree
	 */
	private static Object endExpression(Parser parser, Token token, ParseResult res) {
		if(token.getType() == ETokenTypes.TT_EOF) {
			return res.success(parser.root);
		}		
		return null;
	}
}
