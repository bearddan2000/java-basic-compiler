package compiler.parser;

import java.util.ArrayList;
import java.util.function.Function;

import org.apache.log4j.Logger;

import compiler.error.BaseError;
import compiler.error.InvalidSyntaxError;
import compiler.parser.node.BinOpNode;
import compiler.parser.node.INode;
import compiler.result.IResult;
import compiler.result.ParseResult;
import compiler.token.ETokenTypes;
import compiler.token.Token;

/***
 * Parse tokens into results
 * @author dgb
 *
 */
public class Parser{
	// logger for log4j
	static final Logger logger = Logger.getLogger(Parser.class);
	INode root;
	ArrayList<Token> tokens;
	Token current_tok;
	int tok_idx;

	public Parser(ArrayList<Token> tokens) {
		this.tokens = tokens;
		this.tok_idx = -1;
		this.advance();
	}
/***
 * Check parser result for error
 * @param res ParserResult
 * @return boolean
 */
	public boolean hasError(ParseResult res) {
		if(res.getError() != null) {
			BaseError e = res.getError();
			String msg = e.toString();
			logger.warn(msg);
			System.err.println(msg);
			return true;
		}
		return false;
	}

	/***
	 * Builds the abstract syntax tree
	 * @param delegateA
	 * @param tt
	 * @return an INode
	 */
	private IResult binOp(ArrayList<Function<Parser, Object>> delegate, ETokenTypes...tt) {
		Function<Parser, Object> delegateA = delegate.get(0);
		Function<Parser, Object> delegateB = delegate.get(delegate.size()-1);
		ETokenTypes eTypeA = tt[0];
		ETokenTypes eTypeB = (tt.length == 2) ? tt[1] : tt[tt.length-1];
		ETokenTypes eTypeC = tt[tt.length-1];
		
		ParseResult res = new ParseResult();
		INode right = null;
		INode left = (INode) res.register(delegateA.apply(this));
		if(this.hasError(res)) return res;

		
		while(current_tok.getType() == eTypeA
				|| current_tok.getType() == eTypeB
				|| current_tok.getType() == eTypeC)
		{
			Token t = current_tok;
			res.register(this.advance());
			right = (INode) res.register(delegateB.apply(this));
			if(this.hasError(res)) return res;
			left = new BinOpNode(left, t, right);			
		}
		return res.success(left);
	}
	/***
	 * Changes current token based on token list
	 * @return new token
	 */
	public Token advance() {
		this.tok_idx += 1;
		if(this.tok_idx < this.tokens.size())
			this.current_tok = this.tokens.get(this.tok_idx);
		return this.current_tok;
	}
	/***
	 * Used by factorial TT_EXP
	 * looks at the next token without
	 * actualy moving the pointer
	 * @return temp Token
	 */
	public Token peek() {
		Token tok = null;
		int index = this.tok_idx + 1;
		if(index < this.tokens.size())
			tok = this.tokens.get(index);
		return tok;
	}
	/***
	 * Starts at the top of the tree
	 * @return a result
	 */
	public IResult parse() {
		ParseResult res = (ParseResult) this.exp();
		if(this.hasError(res) && this.current_tok.getType() != ETokenTypes.TT_EOF)
			return (IResult) res.failure(new InvalidSyntaxError(
					this.current_tok.getPos_start(), this.current_tok.getPos_end(),
					"Expected '+', '-', '*' or '/'"
					));
		return res;
	}

	/***
	 * Called by expression and term
	 * handles +,-,EOF,int,floats
	 * checks for ( and )
	 * @return compiler.result.Number
	 */
	public Object atom() 
	{
		ParseResult res = new ParseResult();
		Token tok = this.current_tok;
		Object c = FactorFactory.factor(this, tok, res);
		if(c == null)
			return res.failure(new InvalidSyntaxError(
					tok.getPos_start(), tok.getPos_end(),
					"Expected int or float"
					));
		return c;
	}

	/***
	 * Called by expression and term
	 * handles +,-,EOF,int,floats
	 * checks for ( and )
	 * @return compiler.result.Number
	 */
	public Object factor() 
	{
		ParseResult res = new ParseResult();
		Token tok = this.current_tok;
		if (tok.getType() == ETokenTypes.TT_PLUS
				|| tok.getType() == ETokenTypes.TT_MINUS) {
			res.register(this.advance());
			INode factor = (INode) res.register(this.factor());
			if(this.hasError(res)) return res;
			return res.success(new compiler.parser.node.UniOpNode(tok, factor));
		}
		tok = this.peek();
		if(tok.getType() == ETokenTypes.TT_FACTORIAL)
			return this.atom();
		else if(tok.getType() == ETokenTypes.TT_ROOT)
			return this.nthRoot();
		return this.pow();
	}
	/***
	 * Called recurcively to parse out a tree
	 * @return compiler.result.Number
	 */
	public Object nthRoot() {
		ArrayList<Function<Parser, Object>> delegate = new ArrayList<Function<Parser, Object>>();
		delegate.add(x -> x.atom());
		delegate.add(x -> x.factor());
		return this.binOp(delegate, ETokenTypes.TT_ROOT);
	}
	/***
	 * Called recurcively to parse out a tree
	 * @return compiler.result.Number
	 */
	public Object pow() {
		ArrayList<Function<Parser, Object>> delegate = new ArrayList<Function<Parser, Object>>();
		delegate.add(x -> x.atom());
		delegate.add(x -> x.factor());
		return this.binOp(delegate, ETokenTypes.TT_POW);
	}

	/***
	 * Called recurcively to parse out a tree
	 * @return compiler.result.Number
	 */
	public Object term() {
		ArrayList<Function<Parser, Object>> delegate = new ArrayList<Function<Parser, Object>>();
		delegate.add(x -> x.factor());
		return this.binOp(delegate, ETokenTypes.TT_MUL, ETokenTypes.TT_DIV, ETokenTypes.TT_MOD);
	}

	/***
	 * Called recurcively to parse out a tree
	 * @return compiler.result.Number
	 */
	public Object exp() {
		ArrayList<Function<Parser, Object>> delegate = new ArrayList<Function<Parser, Object>>();
		delegate.add(x -> x.term());
		return this.binOp(delegate, ETokenTypes.TT_PLUS, ETokenTypes.TT_MINUS);
	}
}
