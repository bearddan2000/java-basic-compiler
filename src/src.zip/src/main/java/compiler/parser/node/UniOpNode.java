package compiler.parser.node;

import compiler.error.RuntimeError;
import compiler.interpreter.Context;
import compiler.interpreter.Interpreter;
import compiler.lexer.Position;
import compiler.result.RuntimeResult;
import compiler.result.tree.Root;
import compiler.token.ETokenTypes;
import compiler.token.Token;

public class UniOpNode implements INode {

	Position start, end;
	Token token = null;
	INode left;
	Root root;
	
	public UniOpNode(Token token, INode left) {
		// TODO Auto-generated constructor stub
		this.left = left;
		this.token = token;
		this.start = token.getPos_start();
		this.end = left.getEndPosition();
		this.root = new Root();
	}

	@Override
	public String toString() {
		return "UniOpNode [token=" + token.toString() + ", left=" + left.toString() + "]";
	}

	@Override
	public compiler.result.Number visit(INode node, Context context, Interpreter parent) {
		// TODO Auto-generated method stub
		RuntimeResult res = new RuntimeResult();
		compiler.result.Number answer = new compiler.result.Number();
		RuntimeError e = new RuntimeError(start, end, "", context);
		compiler.result.Number leftNode = parent.visit(left, context);
		answer = this.root.eval(leftNode, this.token.getType());
		
		return answer;
	}

	@Override
	public Position getStartPosition() {
		// TODO Auto-generated method stub
		return this.start;
	}

	@Override
	public Position getEndPosition() {
		// TODO Auto-generated method stub
		return this.end;
	}
	@Override
	public Object getValue() {
		// TODO Auto-generated method stub
		return this.token.getValue();
	}

	@Override
	public Token getToken() {
		// TODO Auto-generated method stub
		return this.token;
	}
}
