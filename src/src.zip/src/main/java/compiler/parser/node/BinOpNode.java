package compiler.parser.node;

import compiler.error.RuntimeError;
import compiler.interpreter.Context;
import compiler.interpreter.Interpreter;
import compiler.lexer.Position;
import compiler.result.RuntimeResult;
import compiler.result.tree.Root;
import compiler.token.Token;

public class BinOpNode implements INode {

	Position start, end;
	Token token = null;
	INode left, right;
	Root root;
	
	public BinOpNode(INode left, Token token, INode right) {
		// TODO Auto-generated constructor stub
		this.left = left;
		this.token = token;
		this.right = right;
		this.root = new Root();
	}

	@Override
	public String toString() {
		return "BinOpNode [token=" + token.toString() + ", left=" + left.toString() + ", right=" + right.toString() + "]";
	}

	@Override
	public compiler.result.Number visit(INode node, Context context, Interpreter parent) {
		// TODO Auto-generated method stub
		RuntimeResult res = new RuntimeResult();
		RuntimeError e = new RuntimeError(start, end, "", context);
		
		compiler.result.Number leftNode = parent.visit(left, context);
		if(res.getError() != null)
			return null;
		compiler.result.Number rightNode = parent.visit(right, context);
		if(res.getError() != null)
			return null;
		
		compiler.result.Number answer = null;
		answer = this.root.eval(leftNode, rightNode, this.token.getType());
		
		return answer;
	}

	@Override
	public Position getStartPosition() {
		// TODO Auto-generated method stub
		return this.start;
	}

	@Override
	public Position getEndPosition() {
		// TODO Auto-generated method stub
		return this.end;
	}
	@Override
	public Object getValue() {
		// TODO Auto-generated method stub
		return this.token.getValue();
	}

	public Token getToken() {
		return token;
	}
}
