package compiler.parser.node;

import compiler.interpreter.Context;
import compiler.interpreter.Interpreter;
import compiler.lexer.Position;
import compiler.result.RuntimeResult;
import compiler.token.Token;

public class NumberNode implements INode{

	private Token token;
	private Position start, end;
	
	public NumberNode() {}
	
	public NumberNode(Token token) {
		// TODO Auto-generated constructor stub
		this.token = token;
		this.start = token.getPos_start();
		this.end = token.getPos_end();
	}

	@Override
	public String toString() {
		return "NumberNode [token=" + token.toString() + "]";
	}

	@Override
	public compiler.result.Number visit(INode node, Context context, Interpreter parent) {
		// TODO Auto-generated method stub
		RuntimeResult res = new RuntimeResult();
		
		compiler.result.Number number = new compiler.result.Number(node.getValue());
		number.setContext(context);
		number.setPos(start, end);
		
		return number;
	}

	@Override
	public Position getStartPosition() {
		// TODO Auto-generated method stub
		return this.start;
	}

	@Override
	public Position getEndPosition() {
		// TODO Auto-generated method stub
		return this.end;
	}

	@Override
	public Object getValue() {
		// TODO Auto-generated method stub
		return this.token.getValue();
	}

	@Override
	public Token getToken() {
		// TODO Auto-generated method stub
		return this.token;
	}

}
