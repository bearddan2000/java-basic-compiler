package compiler.parser.node;

import compiler.interpreter.Context;
import compiler.interpreter.Interpreter;
import compiler.lexer.Position;
import compiler.token.Token;

public interface INode {
	public compiler.result.Number visit(INode node, Context context, Interpreter parent);
	public Position getStartPosition();
	public Position getEndPosition();
	public Object getValue();
	public Token getToken();
}
