package compiler;

import java.util.ArrayList;

import compiler.interpreter.Context;
import compiler.interpreter.Interpreter;
import compiler.lexer.Lexer;
import compiler.parser.Parser;
import compiler.result.ParseResult;
import compiler.token.Token;

public enum EExamples {
    EE_Add("5+1", "6", "Adding"),
    EE_Sub("5-1", "4", "Subtraction"),
    EE_Mul("5*1", "5", "Multiply"),
    EE_Div("4/2", "2", "Divide"),
    EE_Mod("4%2", "2", "Modular division"),
    EE_Mod_Remainder("5%2", "1", "Modular division remainder"),
    EE_Negative("-2", "-2", "Negative"),
    EE_Double_Negative("--2", "2", "Double negative"),
    EE_Positive("2", "2", "Positive"),
    EE_Nth_Root("16V4", "2.0", "Nth root"),
    EE_Factorial("2!", "2", "Factorial"),
    EE_Exponent("2^2", "4.0", "Exponent"),
    EE_Add_Group_Left("(5+1)+1", "7", "Adding grouped left"),
    EE_Sub_Group_Left("(5-1)-1", "3", "Subtraction grouped left"),
    EE_Mul_Group_Left("(5*1)*1", "5", "Multiply grouped left"),
    //EE_Div_Group_Left("(4/2)/2", "1", "Divide grouped left"),
    EE_Add_Group_Right("5+(1+1)", "7", "Adding grouped right"),
    EE_Sub_Group_Right("5-(1-1)", "5", "Subtraction grouped right"),
    EE_Mul_Group_Right("5*(1*1)", "5", "Multiply grouped right"),
    EE_Div_Group_Right("4/(2/2)", "4", "Divide grouped right"),
    EE_Add_None_Group("5+1+1", "7", "Adding none grouped"),
    EE_Sub_None_Group("5-1-1", "3", "Subtraction none grouped"),
    EE_Mul_None_Group("5*1*1", "5", "Multiply none grouped"),
    EE_Div_None_Group("4/2/2", "1", "Divide none grouped"),    
    EE_Add_Float("5.0+1.0", "6.0", "Adding floats"),
    //EE_Sub_Float("5.0-1.0", "4.0", "Subtracting floats"),
    EE_Mul_Float("5.0*1.0", "5.0", "Multiply floats"),
    EE_Div_Float("4.0/2.0", "2.0", "Dividing floats"),
    EE_Mod_Float("4.0%2.0", "2.0", "Modular floats division"),    
    EE_Mod_Float_Remainder("5.0%2.0", "1.0", "Modular floats division remainder"),
    EE_Add_Float_Group_Left("(5.0+1.0)+1.0", "7.0", "Adding floats grouped left"),
    //EE_Sub_Float_Group_Left("(5.0-1.0)-1.0", "3.0", "Subtraction floats grouped left"),
    //EE_Mul_Float_Group_Left("(5.0*1.0)*1.0", "5.0", "Multiply floats grouped left"),
    //EE_Div_Float_Group_Left("(4.0/2.0)/2.0", "1.0", "Divide floats grouped left"),
    EE_Add_Float_Group_Right("5.0+(1.0+1.0)", "7.0", "Adding floats grouped right"),
    //EE_Sub_Float_Group_Right("5.0-(1.0-1.0)", "5.0", "Subtraction floats grouped right"),
    //EE_Mul_Float_Group_Right("5.0*(1.0*1.0)", "5.0", "Multiply floats grouped right"),
    //EE_Div_Float_Group_Right("4.0/(2.0/2.0)", "4.0", "Divide floats grouped right"),
    EE_Add_Float_None_Group("5.0+1.0+1.0", "7.0", "Adding floats none grouped");
    //EE_Sub_Float_None_Group("5.0-1.0-1.0", "3.0", "Subtraction floats none grouped"),
    //EE_Mul_Float_None_Group("5.0*1.0*1.0", "5.0", "Multiply floats none grouped"),
    //EE_Div_Float_None_Group("4.0/2.0/2.0", "1.0", "Divide floats none grouped");

	private String expression = "";
    private String answer = "";
	private String label;

	EExamples(String a, String b, String c) {
		// TODO Auto-generated constructor stub
		expression = a;
		answer = b;
		label = c;
	}
    public String calc() {
    	String input = this.expression;
        Interpreter i = new Interpreter();
        Context context = new Context("<program>");
		
    	Lexer lexer = new Lexer(null, input);
		ArrayList<Token> list = lexer.makeToken();
		Parser parser = new Parser(list);
		ParseResult abs = (compiler.result.ParseResult) parser.parse();
		compiler.result.Number result = i.visit(abs.getNode(), context);
		
		return result.toString();    	
    }
	public String getExpression() {
		return expression;
	}
	public String getLabel() {
		return label;
	}

}
